<?php
// $Id: main.php,v 1.1 2008/03/09 02:26:14 minahito Exp $
define('_MD_PM_ERROR_ACCESS', "讀取錯誤");
define('_MD_PM_ERROR_MAXLENGTH', " {0:toLower} 輸入超過 {1} ，請減少字元。");
define('_MD_PM_ERROR_MESSAGE_SEND', "訊息無法傳送.");
define('_MD_PM_ERROR_OBJECTEXIST', "錯誤輸入於 {0:toLower}.");
define('_MD_PM_ERROR_PLZTRYAGAIN', "請檢查名稱再試.");
define('_MD_PM_ERROR_REQUIRED', "{0} 必填");
define('_MD_PM_ERROR_USERNOEXIST', "使用者不存在.");
define('_MD_PM_ERROR_USERWROTE', "%s 寫道:");
define('_MD_PM_LANG_PREVIOUS', "私人訊息");
define('_MD_PM_LANG_SEND', "送出");
define('_MD_PM_LANG_SENTC', "已送出: ");
define('_MD_PM_LANG_CANCELSEND', "取消");
define('_MD_PM_LANG_CLEAR', "清除");
define('_MD_PM_LANG_DATE', "日期");
define('_MD_PM_LANG_DELETE', "刪除");
define('_MD_PM_LANG_FROM', "來自");
define('_MD_PM_LANG_FROMC', "來自: ");
define('_MD_PM_LANG_INBOX', "收件匣");
define('_MD_PM_LANG_MESSAGE', "訊息");
define('_MD_PM_LANG_MESSAGE_DETAIL', "訊息細節");
define('_MD_PM_LANG_MESSAGEC', "訊息: ");
define('_MD_PM_LANG_MSG_ID', "訊息 ID");
define('_MD_PM_LANG_NEXT', "下一");
define('_MD_PM_LANG_NOTREAD', "未讀");
define('_MD_PM_LANG_ORCLOSEWINDOW', "或按這裏關閉視窗.");
define('_MD_PM_LANG_PROFILE', "資訊");
define('_MD_PM_LANG_REPLY', "回覆");
define('_MD_PM_LANG_SUBJECT', "主題");
define('_MD_PM_LANG_SUBJECTC', "主題: ");
define('_MD_PM_LANG_SUBMIT', "送出");
define('_MD_PM_LANG_TO', "給: ");
define('_MD_PM_MESSAGE_CLICKHERE', "您可以按這裏讀取私人訊息");
define('_MD_PM_MESSAGE_CONFIRM_DELETE_PM', "您真的要刪除以下訊息嗎?");
define('_MD_PM_MESSAGE_DELETED', "訊息已刪除");
define('_MD_PM_MESSAGE_PLZREG', "要使用私人訊息請先註冊!");
define('_MD_PM_MESSAGE_POSTED', "您的訊息已發佈.");
define('_MD_PM_MESSAGE_SORRY', "抱歉!! 您非註冊會員，不能使用此功能.");
define('_MD_PM_MESSAGE_YOUDONTHAVE', "尚未有私人訊息.");

?>

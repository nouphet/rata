<?php
// $Id: modinfo.php,v 1.1 2008/03/09 02:26:13 minahito Exp $
define('_MI_PM_CONF_SEND_TYPE', "選擇直接輸入接收者?");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "選擇結合資料庫使用者 (XOOPS 2.0.x 相容)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "直接輸入 (直接輸入會員名稱)");
define('_MI_PM_NAME', "私人訊息");
define('_MI_PM_NAME_DESC', "私人訊息模組.");

?>
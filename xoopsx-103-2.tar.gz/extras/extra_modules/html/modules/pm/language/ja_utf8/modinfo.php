<?php

define('_MI_PM_CONF_SEND_TYPE', "送信先入力方法");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "コンボボックス(XOOPS 2.0.x互換)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "ユーザー名を直接入力");
define('_MI_PM_NAME', "プライベートメッセージ");
define('_MI_PM_NAME_DESC', "プライベートメッセージの機能を司るモジュール");

?>

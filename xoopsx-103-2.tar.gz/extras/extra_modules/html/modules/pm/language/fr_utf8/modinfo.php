<?php

define('_MI_PM_CONF_SEND_TYPE', "Comment spécifier l'adresse du destinataire?");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "Boîte de sélection (compatible XOOPS 2.0.x)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "Entrée directe du nom d'utilisateur");
define('_MI_PM_NAME', "Message Privé");
define('_MI_PM_NAME_DESC', "Ce module ajoute un service de messagerie privé.");
?>
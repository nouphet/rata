<?php

define('_MI_PM_CONF_SEND_TYPE', "Comment sp�cifier l'adresse du destinataire?");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "Bo�te de s�lection (compatible XOOPS 2.0.x)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "Entr�e directe du nom d'utilisateur");
define('_MI_PM_NAME', "Message Priv�");
define('_MI_PM_NAME_DESC', "Ce module ajoute un service de messagerie priv�.");

?>
<?php
// Translation Info
// $Id: modinfo.php 928 2011-04-14 17:25:48Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
// ############################################################### //
// ## XOOPS Cube Legacy 2.1 - Tradução para o Português do Brasil
// ############################################################### //
// ## Por............: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.net.br
// ############################################################### //
// *************************************************************** //
define("_MI_PM_CONF_SEND_TYPE","Como selecionar o destinatário?");
define("_MI_PM_CONF_SEND_TYPE_COMBO","Caixa de seleção (modo antigo)");
define("_MI_PM_CONF_SEND_TYPE_TEXT","Escrevendo o codinome do destinatário");
define("_MI_PM_NAME","Recados");
define("_MI_PM_NAME_DESC","Este módulo provê o recurso de troca de mensagens privadas (recados) entre os visitantes cadastrados.");
?>
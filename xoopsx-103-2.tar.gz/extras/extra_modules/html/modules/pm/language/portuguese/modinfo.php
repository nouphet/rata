<?php
// Translation Info
// $Id: modinfo.php 928 2011-04-14 17:25:48Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
// ############################################################### //
// ## XOOPS Cube Legacy 2.1 - Tradu��o para o Portugu�s do Brasil
// ############################################################### //
// ## Por............: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.net.br
// ############################################################### //
// *************************************************************** //
define("_MI_PM_CONF_SEND_TYPE","Como selecionar o destinat�rio?");
define("_MI_PM_CONF_SEND_TYPE_COMBO","Caixa de sele��o (modo antigo)");
define("_MI_PM_CONF_SEND_TYPE_TEXT","Escrevendo o codinome do destinat�rio");
define("_MI_PM_NAME","Recados");
define("_MI_PM_NAME_DESC","Este m�dulo prov� o recurso de troca de mensagens privadas (recados) entre os visitantes cadastrados.");
?>
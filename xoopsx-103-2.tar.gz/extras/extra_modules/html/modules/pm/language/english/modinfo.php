<?php

define('_MI_PM_CONF_SEND_TYPE', "How to specify recipient address?");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "Combo box (XOOPS 2.0.x compatible)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "Direct typing (input username directly)");
define('_MI_PM_NAME', "Private Message");
define('_MI_PM_NAME_DESC', "This module provides Private Message functionality.");

?>
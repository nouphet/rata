<?php

define('_MD_PM_ERROR_ACCESS', "Chyba p��stupu");
define('_MD_PM_ERROR_MAXLENGTH', "Vlo�te {0:toLower} s {1} nebo m�n� znaky.");
define('_MD_PM_ERROR_MESSAGE_SEND', "Zpr�va nemohla b�t odesl�na.");
define('_MD_PM_ERROR_OBJECTEXIST', "�patn� vstup do {0:toLower}.");
define('_MD_PM_ERROR_PLZTRYAGAIN', "Vypl�te jm�no a zkuste znovu.");
define('_MD_PM_ERROR_REQUIRED', "{0} je povinn�");
define('_MD_PM_ERROR_USERNOEXIST', "Vybran� u�ivatel nebyl v datab�zi nalezen.");
define('_MD_PM_ERROR_USERWROTE', "%s napsal/a:");
define('_MD_PM_LANG_PREVIOUS', "P�edchoz� zpr�va");
define('_MD_PM_LANG_SEND', "Odeslat zpr�vu");
define('_MD_PM_LANG_SENTC', "Zasl�no: ");
define('_MD_PM_LANG_CANCELSEND', "Zru�it odes�l�n�");
define('_MD_PM_LANG_CLEAR', "Vy�istit");
define('_MD_PM_LANG_DATE', "Datum");
define('_MD_PM_LANG_DELETE', "Smazat");
define('_MD_PM_LANG_FROM', "Od");
define('_MD_PM_LANG_FROMC', "Od: ");
define('_MD_PM_LANG_INBOX', "P�ijat�");
define('_MD_PM_LANG_MESSAGE', "Zpr�va");
define('_MD_PM_LANG_MESSAGE_DETAIL', "Obsah zpr�vy");
define('_MD_PM_LANG_MESSAGEC', "Zpr�va: ");
define('_MD_PM_LANG_MSG_ID', "ID zpr�vy");
define('_MD_PM_LANG_NEXT', "Dal�� zpr�va");
define('_MD_PM_LANG_NOTREAD', "Nep�e�teno");
define('_MD_PM_LANG_ORCLOSEWINDOW', "Nebo zde pro zav�en� okna.");
define('_MD_PM_LANG_PROFILE', "Profil");
define('_MD_PM_LANG_REPLY', "Odpov�d�t");
define('_MD_PM_LANG_SUBJECT', "P�edm�t");
define('_MD_PM_LANG_SUBJECTC', "P�edm�t: ");
define('_MD_PM_LANG_SUBMIT', "Potvrdit");
define('_MD_PM_LANG_TO', "Pro: ");
define('_MD_PM_MESSAGE_CLICKHERE', "Pro prohl�en� soukrom�ch zpr�v m��ete kliknout zde");
define('_MD_PM_MESSAGE_CONFIRM_DELETE_PM', "Opravdu chcete smazat n�sleduj�c� soukrom� zpr�vy?");
define('_MD_PM_MESSAGE_DELETED', "Va�e zpr�va(y) byla(y) smaz�na(y).");
define('_MD_PM_MESSAGE_PLZREG', "Pro zas�l�n� soukrom�ch zpr�v se nejprve zaregistrujte!");
define('_MD_PM_MESSAGE_POSTED', "Va�e zpr�va byla zasl�na.");
define('_MD_PM_MESSAGE_SORRY', "Promi�te! Nejste registrovan� u�ivatel.");
define('_MD_PM_MESSAGE_YOUDONTHAVE', "Nem�te ��dn� soukrom� zpr�vy.");

?>

<?php

define('_MI_PM_CONF_SEND_TYPE', "Jak specifikovat adresu p��jemce?");
define('_MI_PM_CONF_SEND_TYPE_COMBO', "Combo box (XOOPS 2.0.x kompatibiln�)");
define('_MI_PM_CONF_SEND_TYPE_TEXT', "P��mo napsat (vlo�en�m u�ivatelsk�ho jm�na)");
define('_MI_PM_NAME', "Soukrom� zpr�vy");
define('_MI_PM_NAME_DESC', "Modul pro soukrom� zpr�vy mezi u�ivateli.");

?>

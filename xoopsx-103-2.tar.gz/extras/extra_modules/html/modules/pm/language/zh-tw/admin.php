<?php

define("_PM_AM_PRUNE", "刪除");
//define("_PM_AM_PRUNE", "Prune");

define("_PM_AM_PRUNEAFTER", "刪除某日之後張貼的訊息 (空白則不指定開始日期)");
//define("_PM_AM_PRUNEAFTER", "Prune messages posted after this date (leave blank for no start date)");

define("_PM_AM_PRUNEBEFORE", "刪除某日之前張貼的訊息 (空白則不指定結束日期)");
//define("_PM_AM_PRUNEBEFORE", "Prune messages posted before this date (leave blank for no end date)");

define("_PM_AM_ONLYREADMESSAGES", "只刪除讀取的信件");
//define("_PM_AM_ONLYREADMESSAGES", "Prune only read messages");

define("_PM_AM_INCLUDESAVE", "包括使用者 \"儲存\" 匣中的信件");
//define("_PM_AM_INCLUDESAVE", "Include messages in users' \"save\" folders");

define("_PM_AM_NOTIFYUSERS", "通知刪信有受到影響的使用者?");
//define("_PM_AM_NOTIFYUSERS", "Notify affected users about the prune?");

define("_PM_AM_MESSAGESPRUNED", "%u 封信已被刪除");
//define("_PM_AM_MESSAGESPRUNED", "%u Messages Pruned");

define("_PM_AM_ERRORWHILEPRUNING", "刪除的過程中發生錯誤");
//define("_PM_AM_ERRORWHILEPRUNING", "An error occurred during prune");
?>

<?php

define('_MI_PM_CONF_SEND_TYPE', '如何正確輸入收件者位址？');
define('_MI_PM_CONF_SEND_TYPE_COMBO', '複合（相容 XOOPS 2.0.x）');
define('_MI_PM_CONF_SEND_TYPE_TEXT', '簡潔 （直接輸入使用者名稱）');
define('_MI_PM_NAME', '私人訊息');
define('_MI_PM_NAME_DESC', '這個模組提供私人訊息的功能。');

?>
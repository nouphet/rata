<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: filter.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_BADIPCONTAIN","aaa.bbb.ccc ir� proibir visitantes com um IP que contenha aaa.bbb.ccc");
define("_AM_BADIPEND","aaa.bbb.ccc$ ir� proibir visitantes com um IP que termine com with aaa.bbb.ccc");
define("_AM_BADIPS","Banir endere�o IP");
define("_AM_BADIPSTART","aaa.bbb.ccc ir� proibir visitantes com um IP que inicie com with aaa.bbb.ccc");
define("_AM_BADUNAMES","Lista de nomes de associados proibidos");
define("_AM_BADWORDS","Lista de palavras censuradas");
define("_AM_DBUPDATED","Informa��es gravadas corretamente.");
define("_AM_ENTERIPS","Escreva os endere�os IP que devem ser banidos deste site. <br/>Escreva apenas um endere�o IP por linha.");
define("_AM_ENTERUNAMES","Escreva os nomes que n�o devem ser usados como nome de associados.<br/>Escreva uma por linha, (mai�sculas s�o ignoradas).");
define("_AM_ENTERWORDS","Escreva as palavras que devem ser censuradas nas mensagens de associados. As palavras ser�o substidu�das por ####.<br/>Escreva uma palavra por linha, (mai�sculas s�o ignoradas).");
define("_AM_FILTERSETTINGS","Configura��es de Filtro do Site");
?>
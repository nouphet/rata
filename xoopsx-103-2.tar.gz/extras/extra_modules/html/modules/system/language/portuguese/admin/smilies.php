<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: smilies.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_DBUPDATED","Banco de dados atualizado corretamente.");
define("_AM_DISPLAYF","Mostrar");
define("_AM_SMILESCONTROL","Configura��o dos Emos");
define("_AM_CODE","C�digo");
define("_AM_SMILIE","Imagem");
define("_AM_ACTION","A��es");
define("_AM_EDIT","Editar");
define("_AM_DEL","Remover");
define("_AM_CNRFTSD","Imposs�vel incluir Emo.");
define("_AM_ADDSMILE","Incluir um emo");
define("_AM_EDITSMILE","Editar um emo");
define("_AM_SMILECODE","C�digo do emo:");
define("_AM_SMILEURL","URL do emo:");
define("_AM_SMILEEMOTION","Descri��o");
define("_AM_ADD","Incluir");
define("_AM_SAVE","Gravar");
define("_AM_WAYSYWTDTS","Deseja remover este emo?");
?>
<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: admin.php 336 2009-07-31 09:53:22Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_MD_AM_ADGS","Grupos & permiss�es");
define("_MD_AM_AVATARS","Avatares");
define("_MD_AM_BANS","Publicidade");
define("_MD_AM_BKAD","Blocos");
define("_MD_AM_COMMENTS","Coment�rios");
define("_MD_AM_DBUPDATED","As informa��es foram gravadas corretamente.");
define("_MD_AM_FINDUSER","Localizar associado(s)");
define("_MD_AM_IMAGES","Banco de imagens");
define("_MD_AM_MDAD","M�dulos");
define("_MD_AM_MLUS","Enviar e-mail");
define("_MD_AM_PERMADDNG","Could not add %s permission to %s for group %s");
define("_MD_AM_PERMADDNGP","Todos os itens relacionados devem ser selecionados");
define("_MD_AM_PERMADDOK","Added %s permission to %s for group %s");
define("_MD_AM_PERMRESETNG","Could not reset group permission for module %s");
define("_MD_AM_PREF","Defini��es");
define("_MD_AM_RANK","Gradua��es dos associados");
define("_MD_AM_SMLS","Emos");
define("_MD_AM_TPLSETS","Modelos");
define("_MD_AM_USER","Editar associados");
define("_MD_AM_VRSN","Vers�o");
?>
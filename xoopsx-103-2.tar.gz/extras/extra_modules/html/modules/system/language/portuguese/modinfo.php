<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: modinfo.php 336 2009-07-31 09:53:22Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_MI_SYSTEM_ADMENU1","Publicidade");
define("_MI_SYSTEM_ADMENU10","Editar associado");
define("_MI_SYSTEM_ADMENU11","Contatar associado");
define("_MI_SYSTEM_ADMENU12","Localizar associado");
define("_MI_SYSTEM_ADMENU13","Banco de imagens");
define("_MI_SYSTEM_ADMENU14","Avatares");
define("_MI_SYSTEM_ADMENU15","Modelos Smarty");
define("_MI_SYSTEM_ADMENU16","Coment�rios");
define("_MI_SYSTEM_ADMENU2","Blocos");
define("_MI_SYSTEM_ADMENU3","Grupos & permiss�es");
define("_MI_SYSTEM_ADMENU5","M�dulos");
define("_MI_SYSTEM_ADMENU6","Defini��es");
define("_MI_SYSTEM_ADMENU7","Emos");
define("_MI_SYSTEM_ADMENU9","Gradua��es");
define("_MI_SYSTEM_BNAME10","Novos associados");
define("_MI_SYSTEM_BNAME11","�ltimos coment�rios");
define("_MI_SYSTEM_BNAME12","Notifica��es");
define("_MI_SYSTEM_BNAME13","Temas");
define("_MI_SYSTEM_BNAME2","Meu menu");
define("_MI_SYSTEM_BNAME3","Entrar");
define("_MI_SYSTEM_BNAME4","Pesquisa");
define("_MI_SYSTEM_BNAME5","Conte�do pendente");
define("_MI_SYSTEM_BNAME6","Principal");
define("_MI_SYSTEM_BNAME7","Quem faz");
define("_MI_SYSTEM_BNAME8","Quem nos visita");
define("_MI_SYSTEM_BNAME9","Os mais participativos:");
define("_MI_SYSTEM_DESC","Administra��o do m�dulo Sistema, com as principais configura��es do portal.");
define("_MI_SYSTEM_NAME","Sistema");
?>
<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: blocksadmin.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_ABOVEORG","Antes do conte�do original");
define("_AM_ACTION","A��es");
define("_AM_ADDBLOCK","Criar um novo bloco");
define("_AM_ADVANCED","Op��es avan�adas");
define("_AM_AFNOSMILE","Autom�tico (emos desabilitados)");
define("_AM_AFTERORG","Ap�s o conte�do original");
define("_AM_AFWSMILE","Autom�tico (emos habilitados)");
define("_AM_ALLPAGES","Todas as p�ginas");
define("_AM_BADMIN","Administra��o dos blocos");
define("_AM_BALIAS","Alias");
define("_AM_BCACHETIME","Dura��o do cache");
define("_AM_BLKDESC","Descri��o");
define("_AM_BLKTYPE","Tipo de bloco");
define("_AM_BLOCKTAG1","%s resultar� %s");
define("_AM_CBCENTER","central-centro");
define("_AM_CBLEFT","centro-esquerda");
define("_AM_CBRIGHT","centro-direita");
define("_AM_CENTER","Central");
define("_AM_CLONE","Clonar");
define("_AM_CLONEBLK","Clonado");
define("_AM_CLONEBLOCK","Clonar o bloco");
define("_AM_CONTENT","Conte�do");
define("_AM_CTYPE","Tipo de conte�do");
define("_AM_CUSTOMHTML","Bloco personalizado (HTML)");
define("_AM_CUSTOMNOSMILE","Bloco personalizado (formato autom�tico)");
define("_AM_CUSTOMPHP","Bloco personalizado (PHP)");
define("_AM_CUSTOMSMILE","Bloco personalizado (autom�tico + smilies)");
define("_AM_DBUPDATED","Banco de dados atualizado corretamente.");
define("_AM_DELETE","Remover");
define("_AM_DISPRIGHT","Mostrar apenas os blocos da direita");
define("_AM_EDIT","Editar");
define("_AM_EDITBLOCK","Editar um bloco");
define("_AM_EDITTPL","Editar modelo");
define("_AM_GROUP","Grupo");
define("_AM_HTML","HTML");
define("_AM_LEFT","Esquerda");
define("_AM_LISTBLOCK","Listar todos os blocos");
define("_AM_MODULE","M�dulo");
define("_AM_MODULECANT","Este bloco n�o pode ser apagado diretamente. Se voc� deseja desabilitar este bloco, desative o m�dulo.");
define("_AM_NAME","Nome");
define("_AM_NOTSELNG","'%s' n�o est� selecionado.");
define("_AM_OPTIONS","Op��es");
define("_AM_PHP","Script PHP");
define("_AM_POSCONTT","Posi��o do conte�do adicional");
define("_AM_RIGHT","Direita");
define("_AM_RUSUREDEL","Voc� tem certeza de que deseja remover o m�dulo <b>%s</b>?");
define("_AM_SAVECHANGES","Gravar as altera��es");
define("_AM_SBLEFT","Bloco lateral - esquerda");
define("_AM_SBRIGHT","Bloco lateral - direita");
define("_AM_SIDE","Tipo");
define("_AM_SUBMIT","Enviar");
define("_AM_SVISIBLEIN","Mostrar blocos vis�veis em %s");
define("_AM_SYSTEMCANT","Os blocos do sistema n�o podem ser apagados.");
define("_AM_TITLE","T�tulo");
define("_AM_TOPONLY","Somente a p�gina principal");
define("_AM_TOPPAGE","P�gina principal");
define("_AM_UNASSIGNED","Indefinido");
define("_AM_USEFULTAGS","C�digos �teis:");
define("_AM_VISIBLE","Mostrar");
define("_AM_VISIBLEIN","Mostrar em");
define("_AM_WEIGHT","Posi��o");
?>
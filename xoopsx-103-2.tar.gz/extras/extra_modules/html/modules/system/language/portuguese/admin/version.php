<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: version.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_DBUPDATED","Informa��es atualizadas corretamente.");
?>
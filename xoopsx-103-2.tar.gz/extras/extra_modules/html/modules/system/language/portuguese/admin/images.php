<?php
// Translation Info
// *************************************************************** //
// ############################################################### //
// ## XOOPS 2.0.9 - Brazilian Portuguese Translation ## //
// ############################################################### //
// ## Translator.....: Mikhail Miguel ## //
// ## E-mail.........: mikhail@ajato.com.br ## //
// ## Website.......: http://xoops.codigolivre.org.br ## //
// ############################################################### //
// *************************************************************** //
define("_MD_IMGMAIN","Imagens");
define("_MD_ADDIMGCAT","Incluir uma categoria de imagens");
define("_MD_EDITIMGCAT","Editar uma categoria de imagens");
define("_MD_IMGCATNAME","Nome");
define("_MD_IMGCATRGRP","Select groups for image manager use:<br/><br/><span style='font-weight: normal;?>These are groups allowed to use the image manager for selecting images but not uploading. Administrador has automatic access.</spa?>");
define("_MD_IMGCATWGRP","Selecionar os grupos que t�m permiss�o de enviar imagens:<br/><br/><span style='font-weight: normal;?>Typical usage is for moderator and admin groups.</spa?>");
define("_MD_IMGCATWEIGHT","Ordenar por");
define("_MD_IMGCATDISPLAY","Mostrar esta categoria?");
define("_MD_IMGCATSTRTYPE","Fazer o envio de imagens para:");
define("_MD_STRTYOPENG","Esta configura��o n�o pode ser alterada posteriormente.");
define("_MD_INDB","Gravar as imagens no banco de dados (como informa��o bin�ria 'blob')");
define("_MD_ASFILE","Gravar as imagens como arquivos (no diret�rio de uploads)<br/>");
define("_MD_RUDELIMGCAT","Tem certeza de que deseja remover esta categoria e todas as suas respectivas imagens?");
define("_MD_RUDELIMG","Tem certeza de que deseja remover esta imagem?");
define("_MD_FAILDEL","Falha ao remover a imagem %s do banco de dados");
define("_MD_FAILDELCAT","Falha ao remover a categoria de imagens %s do banco de dados");
define("_MD_FAILUNLINK","Falha ao remover a imagem %s do disco");
?>
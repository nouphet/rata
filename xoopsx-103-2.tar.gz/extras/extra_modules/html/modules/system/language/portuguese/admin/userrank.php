<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: userrank.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_ACTION","A��es");
define("_AM_ACTIVE","Ativar");
define("_AM_ADD","Incluir");
define("_AM_ADDNEWRANK","Incluir uma nova gradua��o");
define("_AM_DBUPDATED","Altera��es realizadas corretamente.");
define("_AM_DEL","Remover");
define("_AM_EDIT","Editar");
define("_AM_EDITRANK","Editar gradua��es");
define("_AM_IMAGE","Imagem");
define("_AM_MAXPOST","M�ximo de mensagens");
define("_AM_MINPOST","M�nimo de mensagens");
define("_AM_NO","N�o");
define("_AM_OFF","Desabilitado");
define("_AM_ON","Habilitado");
define("_AM_RANKSSETTINGS","Configura��es das gradua��es dos associados");
define("_AM_RANKTITLE","T�tulo da gradua��o");
define("_AM_SAVECHANGE","Gravar altera��es");
define("_AM_SPECIAL","Especial");
define("_AM_SPECIALCAN","(gradua��es especiais podem ser designadas para associados independentemente do n�mero de mensagens enviadas pelos associados)");
define("_AM_SPERANK","Gradua��es especiais");
define("_AM_TITLE","T�tulo");
define("_AM_VALIDUNDER","(um arquivo de imagem v�lido no diret�rio <b>%s</b>)");
define("_AM_WAYSYWTDTR","Tem certeza que deseja remover esta gradua��o?");
define("_AM_YES","Sim");
?>
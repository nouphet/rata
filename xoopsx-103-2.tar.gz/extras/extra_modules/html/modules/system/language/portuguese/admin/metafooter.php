<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: metafooter.php 616 2010-04-27 22:04:08Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_AM_ADDCODE","Incluir c�digo");
define("_AM_BESURELINK","Assegure-se de que os links sejam digitados por completo, iniciando desde o http:");
define("_AM_CLEAR","Limpar");
define("_AM_DBUPDATED","Banco de dados atualizado corretamente.");
define("_AM_EDITMKF","Editar palavras-chave para as tags Meta e Footer");
define("_AM_ERRDELOLD","Ocorreu um erro ao remover uma tag metafooter antiga");
define("_AM_ERRINSERT","Ocorreu um erro ao incluir uma nova tag metafooter");
define("_AM_FOOTER","Rodap�");
define("_AM_METAKEY","Palavras-chave para a metatag");
define("_AM_TYPEBYCOM","Escreva as palavras-chaves separadas por v�rgulas (ex: XOOPS, PHP, mySQL, portal system)");
?>
<?php
// Translation Info
// $Id: findusers.php 928 2011-04-14 17:25:48Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
// ############################################################### //
// ## XOOPS Cube Legacy 2.1 - Tradu��o para o Portugu�s do Brasil
// ############################################################### //
// ## Por............: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.net.br
// ## Plus...........: http://card.ly/mikhail
// ############################################################### //
// *************************************************************** //
define("_AM_FINDUS","Pesquisar associado(s)");
define("_AM_AVATAR","Avatar");
define("_AM_REALNAME","Nome");
define("_AM_REGDATE","associado desde");
define("_AM_EMAIL","E-mail");
define("_AM_PM","recado");
define("_AM_URL","URL");
define("_AM_PREVIOUS","� Anteriores");
define("_AM_NEXT","Pr�ximos �");
define("_AM_USERSFOUND","%s associado(s) encontrado(s).");
define("_AM_ACTUS","associados ativos: %s");
define("_AM_INACTUS","associados inativos: %s");
define("_AM_NOFOUND","Nenhum associado encontrado.");
define("_AM_UNAME","Codinome");
define("_AM_ICQ","ICQ");
define("_AM_AIM","AIM");
define("_AM_YIM","YIM");
define("_AM_MSNM","MSN");
define("_AM_LOCATION","Localidade cont�m");
define("_AM_OCCUPATION","Ocupa��o cont�m");
define("_AM_INTEREST","Interesses cont�m");
define("_AM_URLC","Website pessoal cont�m");
define("_AM_LASTLOGMORE","�ltimo acesso a mais de <span style='color:#ff0000'>X</span> dias.");
define("_AM_LASTLOGLESS","�ltimo acesso a menos de <span style='color:#ff0000'>X</span> dias.");
define("_AM_REGMORE","Registro com mais de <span style='color:#ff0000'>X</span> dias.");
define("_AM_REGLESS","Registro com menos de <span style='color:#ff0000'>X</span> dias.");
define("_AM_POSTSMORE","Com mais de <span style='color:#ff0000'>X</span> mensagens.");
define("_AM_POSTSLESS","Com menos de <span style='color:#ff0000'>X</span> mensagens.");
define("_AM_SORT","Classificar por");
define("_AM_ORDER","Classificar em");
define("_AM_LASTLOGIN","�ltima visita");
define("_AM_POSTS","N�mero de mensagens");
define("_AM_ASC","Ordem crescente");
define("_AM_DESC","Ordem decrescente");
define("_AM_LIMIT","N�mero de associados por p�gina");
define("_AM_RESULTS","Resultados da pesquisa");
define("_AM_SHOWMAILOK","Mostrar associados que:");
define("_AM_MAILOK","Aceitam receber e-mail");
define("_AM_MAILNG","N�o aceitam receber e-mail");
define("_AM_SHOWTYPE","Situa��o");
define("_AM_ACTIVE","Ativos");
define("_AM_INACTIVE","Inativos");
define("_AM_BOTH","Todos");
define("_AM_SENDMAIL","Enviar e-mail");
define("_AM_ADD2GROUP","Incluir no grupo %s");
?>
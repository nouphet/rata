<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Vers�o em Portugu�s
// ** $Id: avatars.php 336 2009-07-31 09:53:22Z mikhail $
// **	License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_MD_AVATARMAN","Administra��o dos Avatares");
define("_MD_SYSAVATARS","Avatares do sistema");
define("_MD_CSTAVATARS","Avatares enviados");
define("_MD_ADDAVT","Incluir avatar");
define("_MD_USERS","associados usando este avatar:");
define("_MD_RUDELIMG","Tem certeza de que deseja remover este avatar?");
define("_MD_FAILDEL","N�o foi poss�vel remover o avatar %s do banco de dados.");
?>
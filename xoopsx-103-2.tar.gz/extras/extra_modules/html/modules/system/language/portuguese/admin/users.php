<?php
// Translation Info
// ****************************************************** //
// ##################################################### //
// ## XOOPS 2.0.9 - Brazilian Portuguese Translation ## //
// ################################################### //
// ## Translator.....: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.underpop.com
// ######################################################
// ******************************************************...
define("_AM_ACCESSLEV","N�vel de acesso");
define("_AM_ADDUSER","Incluir associado");
define("_AM_AIM","AIM");
define("_AM_AOUTVTEAD","Permitir que os outros associados vejam o meu endere�o de e-mail.");
define("_AM_AVATAR","Avatar");
define("_AM_AYSYWTDU","Tem certeza de que deseja remover o associado <b>%s</b>?");
define("_AM_BYTHIS","Ser�o removidas permanentemente todas as informa��es deste associado.");
define("_AM_CHANGEONLY","(apenas para altera��es)");
define("_AM_CNGTCOM","N�o foi poss�vel obter o n�mero total de coment�rios");
define("_AM_CNGTST","N�o foi poss�vel obter o n�mero total de artigos");
define("_AM_CNGUSERID","N�o foi poss�vel obter o n�mero identificador do associado");
define("_AM_CNRNU","N�o foi poss�vel cadastrar o novo associado.");
define("_AM_CNUUSER","N�o foi poss�vel modificar associado");
define("_AM_COMMENTS","N�mero de textos enviados (sem contar com as not�cias):");
define("_AM_DBUPDATED","Informa��es gravadas corretamente.");
define("_AM_DELUSER","Remover associado");
define("_AM_EDEUSER","Editar ou remover associados");
define("_AM_EMAIL","E-mail");
define("_AM_GO","Prosseguir");
define("_AM_ICQ","ICQ");
define("_AM_INDICATECOF","Os ateriscos indicam os campos obrigat�rios.");
define("_AM_INTEREST","Interesses");
define("_AM_LIST","Listar");
define("_AM_LOCATION","Localidade");
define("_AM_MODIFYUSER","Modificar associado");
define("_AM_MSNM","MSNM");
define("_AM_NAME","Nome");
define("_AM_NICKNAME","Codinome");
define("_AM_NO","N�o");
define("_AM_NOTACTIVE","Este associado ainda n�o foi habilitado. Deseja habilitar este associado?");
define("_AM_NOUSERS","Nenhum associado selecionado");
define("_AM_NSRA","Nenhuma gradua��o especial para associado");
define("_AM_NSRID","N�o h� gradua��es especias no banco de dados");
define("_AM_OCCUPATION","Ocupa��o");
define("_AM_OPTION","Op��o");
define("_AM_PASSWORD","Senha");
define("_AM_PTBBTSDIYT","Clique no bot�o abaixo para sincronizar os dados, caso voc� suspeite de que as informa��es de envio acima n�o parecem indicar o seu real estado.");
define("_AM_RANK","Posi��o");
define("_AM_RETYPEPD","Reescreva a senha");
define("_AM_SIGNATURE","Assinatura");
define("_AM_STNPDNM","Lamento, mas as novas senhas n�o conferem. Retorne e tente de novo.");
define("_AM_STORIES","Not�cias");
define("_AM_SYNCHRONIZE","SINCRONIZAR");
define("_AM_THEME","Tema");
define("_AM_UPDATEUSER","Atualizar associado");
define("_AM_URL","URL");
define("_AM_USERDONEXIT","O associado n�o existe.");
define("_AM_USERID","N� identificador do associado");
define("_AM_USERINFO","Informa��es-associado");
define("_AM_USERPOST","Postagens deste associado:");
define("_AM_YES","Sim");
define("_AM_YIM","YIM");
define("_AM_YMCACF","� necess�rio preencher todos os campos obrigat�rios.");
?>
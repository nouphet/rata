<?php
// Translation Info
// ****************************************************** //
// ##################################################### //
// ## XOOPS 2.0.9 - Brazilian Portuguese Translation ## //
// ################################################### //
// ## Translator.....: Mikhail Miguel #//
// ## E-mail.........: mikhail.miguel@gmail.com #/
// ## Website........: http://xoops.underpop.com #
// ######################################################
// ******************************************************...
define("_AM_ACCESSRIGHTS","Permiss�es de acesso aos m�dulos");
define("_AM_ACTIVERIGHTS","Permiss�es de administra��o dos m�dulos");
define("_AM_ADDBUTTON","incluir �");
define("_AM_ADMINNO","� necess�rio pelo menos um associado no grupo Adminstradores.");
define("_AM_AREUSUREDEL","Voc� tem certeza de que deseja remover este grupo?");
define("_AM_BLOCKRIGHTS","Permiss�es de acesso aos blocos");
define("_AM_CREATENEWADG","Criar um novo grupo");
define("_AM_DBUPDATED","Informa��es gravadas corretamente.");
define("_AM_DELBUTTON","� remover");
define("_AM_DELETE","Remover");
define("_AM_DELETEADG","Remover grupo");
define("_AM_DESCRIPTION","Descri��o");
define("_AM_EDITADG","Editar grupos");
define("_AM_EDITMEMBER","Incluir ou remover associados");
define("_AM_FINDU4GROUP","Incluir ou remover associados");
define("_AM_GROUPSMAIN","Grupos");
define("_AM_IFADMIN","Se a op��o de permiss�o para um m�dulo estiver assinalada, a permiss�o de acesso para este m�dulo estar� sempre ligada.");
define("_AM_INDICATES","Os asteriscos indicam os campos obrigat�rios");
define("_AM_MEMBERS","Associados");
define("_AM_MODIFY","Modificar");
define("_AM_MODIFYADG","Modificar grupo");
define("_AM_NAME","Nome");
define("_AM_NO","N�o");
define("_AM_NONMEMBERS","N�o-associados");
define("_AM_SYSTEMRIGHTS","Permiss�es para a administra��o do sistema");
define("_AM_UNEED2ENTER","� necess�rio digitar as informa��es solicitadas.");
define("_AM_UPDATEADG","Atualizar grupo");
define("_AM_YES","Sim");
?>
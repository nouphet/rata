<?php
//%%%%%%	Admin Module Name  Version 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);


?>
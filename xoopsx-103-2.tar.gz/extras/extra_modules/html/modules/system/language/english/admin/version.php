<?php
// $Id: version.php,v 1.1 2007/05/15 02:35:21 minahito Exp $
//%%%%%%	Admin Module Name  Version 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);


?>
<?php
// $Id
//%%%%%% Avatar Manager %%%%%
define('_MD_AVATARMAN','Avatar Manager');

define('_MD_SYSAVATARS','System Avatars');
define('_MD_CSTAVATARS','Custom Avatars');
define('_MD_ADDAVT','Add Avatar');
define('_MD_USERS','Users using this avatar');
define('_MD_RUDELIMG','Are you sure that you want to delete this avatar image?');
define('_MD_FAILDEL', 'Failed deleting avatar %s from the database');
?>
<?php
// $Id: userrank.php,v 1.1 2007/05/15 02:35:21 minahito Exp $
//%%%%%%	Admin Module Name  UserRank 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);
define("_AM_RANKSSETTINGS","User Ranks Settings");
define("_AM_TITLE","Title");
define("_AM_MINPOST","Min. Posts");
define("_AM_MAXPOST","Max. Posts");
define("_AM_IMAGE","Image");
define("_AM_SPERANK","Special Ranks");
define("_AM_ON","on");
define("_AM_OFF","off");
define("_AM_EDIT","Edit");
define("_AM_DEL","Delete");
define("_AM_ADDNEWRANK","Add a New Rank");
define("_AM_RANKTITLE","Rank Title");
define("_AM_SPECIAL","Special");
define("_AM_ADD","Add");
define("_AM_EDITRANK","Edit Ranks");
define("_AM_ACTIVE","active");
define("_AM_SAVECHANGE","Save Changes");
define("_AM_WAYSYWTDTR","WARNING: Are you sure you want to delete this Ranking?");
define("_AM_YES","Yes");
define("_AM_NO","No");
define("_AM_VALIDUNDER","(A valid image file under <b>%s</b> directory)");
define("_AM_SPECIALCAN","(Special ranks can be assigned to users irrespective of the number of user posts)");
define("_AM_ACTION","Action");
?>
<?php
// $Id: admin.php,v 1.1 2007/05/15 02:35:27 minahito Exp $

if (!defined('_MD_AM_DBUPDATED')) {

//%%%%%%	File Name  admin.php 	%%%%%
define('_MD_AM_DBUPDATED','Database Updated Successfully!');


// Admin Module Names
define('_MD_AM_ADGS','Groups');
define('_MD_AM_BANS','Banners');
define('_MD_AM_BKAD','Blocks');
define('_MD_AM_MDAD','Modules');
define('_MD_AM_SMLS','Smilies');
define('_MD_AM_RANK','User Ranks');
define('_MD_AM_USER','Edit Users');
define('_MD_AM_FINDUSER', 'Find Users');
define('_MD_AM_PREF','Preferences');
define('_MD_AM_VRSN','Version');
define('_MD_AM_MLUS', 'Mail Users');
define('_MD_AM_IMAGES', 'Image Manager');
define('_MD_AM_AVATARS', 'Avatars');
define('_MD_AM_TPLSETS', 'Templates');
define('_MD_AM_COMMENTS', 'Comments');

}

?>
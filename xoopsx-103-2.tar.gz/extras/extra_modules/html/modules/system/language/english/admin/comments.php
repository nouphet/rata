<?php
// $Id: comments.php,v 1.1 2007/05/15 02:35:21 minahito Exp $
//%%%%%% Comment Manager %%%%%
define('_MD_AM_COMMMAN','Comment Manager');

define('_MD_AM_LISTCOMM','List Comments');
define('_MD_AM_ALLMODS','All modules');
define('_MD_AM_ALLSTATUS','Any status');
define('_MD_AM_MODULE','Module');
define('_MD_AM_COMFOUND','%s comment(s) found.');
?>
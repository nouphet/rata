<?php
define("_AM_DBUPDATED","Informações atualizadas corretamente.");
?>
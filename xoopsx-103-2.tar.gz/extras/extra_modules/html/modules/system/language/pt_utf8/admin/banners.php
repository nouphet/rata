<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Versão em Português
// ** $Id: banners.php 336 2009-07-31 09:53:22Z mikhail $
// ** License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
# define("_AM_DBUPDATED",_MD_AM_DBUPDATED);
define("_AM_DBUPDATED","Banners atualizados corretamente!");
define("_AM_CURACTBNR","Banners ativos");
define("_AM_BANNERID","ID do banner");
define("_AM_IMPRESION","Impressões");
define("_AM_IMPLEFT","Imp. Totais");
define("_AM_CLICKS","Cliques");
define("_AM_NCLICKS","% cliques");
define("_AM_CLINAME","Anunciante");
define("_AM_FUNCTION","Ações");
define("_AM_UNLIMIT","Ilimitado");
define("_AM_EDIT","Editar");
define("_AM_DELETE","Remover");
define("_AM_FINISHBNR","Banners parados");
define("_AM_IMPD","Impressões");
define("_AM_STARTDATE","Início");
define("_AM_ENDDATE","Fim");
define("_AM_ADVCLI","Anunciantes");
define("_AM_ACTIVEBNR","Banners ativos");
define("_AM_CONTNAME","Contato");
define("_AM_CONTMAIL","E-mail de contato");
define("_AM_CLINAMET","Anunciante:");
define("_AM_ADDNWBNR","Incluir um banner");
define("_AM_IMPPURCHT","Impressões contratadas:");
define("_AM_IMGURLT","URL da figura:");
define("_AM_CLICKURLT","URL:");
define("_AM_ADDBNR","Incluir banner");
define("_AM_ADDNWCLI","Incluir um anunciante");
define("_AM_CONTNAMET","Contato:");
define("_AM_CONTMAILT","E-mail de contato:");
define("_AM_CLILOGINT","Anunciante:");
define("_AM_CLIPASST","Senha:");
define("_AM_ADDCLI","Incluir anunciante");
define("_AM_DELEBNR","Remover banner");
define("_AM_SUREDELE","Você tem certeza de que deseja remover este banner?");
define("_AM_NO","Não");
define("_AM_YES","Sim");
define("_AM_EDITBNR","Editar banner");
define("_AM_ADDIMPT","Incluir impressões:");
define("_AM_PURCHT","Contratado:");
define("_AM_MADET","Feito por:");
define("_AM_CHGBNR","Editar banner");
define("_AM_DELEADC","Remover anunciante");
define("_AM_SUREDELCLI","Você está prestes a remover o anunciante <strong>%s</strong> com todas as suas respectivas faixas publicitárias.");
define("_AM_NOBNRRUN","Este anunciante não possui nenhum banner ativo.");
define("_AM_WARNING","ATENÇÃO.");
define("_AM_ACTBNRRUN","Este anunciante possui as seguintes faixas publicitárias ativas:");
define("_AM_SUREDELBNR","Tem certeza de que deseja Remover este anunciante e todos os seus banners?");
define("_AM_EDITADVCLI","Editar anunciante com propaganda");
define("_AM_EXTINFO","Informações adicionais:");
define("_AM_CHGCLI","Editar dados do anunciante");
define("_AM_USEHTML","Usar HTML?");
define("_AM_CODEHTML","Código HTML:");
?>
<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Versão em Português
// ** $Id: modinfo.php 336 2009-07-31 09:53:22Z mikhail $
// ** License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_MI_SYSTEM_ADMENU1","Publicidade");
define("_MI_SYSTEM_ADMENU10","Editar associado");
define("_MI_SYSTEM_ADMENU11","Contatar associado");
define("_MI_SYSTEM_ADMENU12","Localizar associado");
define("_MI_SYSTEM_ADMENU13","Banco de imagens");
define("_MI_SYSTEM_ADMENU14","Avatares");
define("_MI_SYSTEM_ADMENU15","Modelos Smarty");
define("_MI_SYSTEM_ADMENU16","Comentários");
define("_MI_SYSTEM_ADMENU2","Blocos");
define("_MI_SYSTEM_ADMENU3","Grupos & permissões");
define("_MI_SYSTEM_ADMENU5","Módulos");
define("_MI_SYSTEM_ADMENU6","Definições");
define("_MI_SYSTEM_ADMENU7","Emos");
define("_MI_SYSTEM_ADMENU9","Graduações");
define("_MI_SYSTEM_BNAME10","Novos associados");
define("_MI_SYSTEM_BNAME11","Últimos comentários");
define("_MI_SYSTEM_BNAME12","Notificações");
define("_MI_SYSTEM_BNAME13","Temas");
define("_MI_SYSTEM_BNAME2","Meu menu");
define("_MI_SYSTEM_BNAME3","Entrar");
define("_MI_SYSTEM_BNAME4","Pesquisa");
define("_MI_SYSTEM_BNAME5","Conteúdo pendente");
define("_MI_SYSTEM_BNAME6","Principal");
define("_MI_SYSTEM_BNAME7","Quem faz");
define("_MI_SYSTEM_BNAME8","Quem nos visita");
define("_MI_SYSTEM_BNAME9","Os mais participativos:");
define("_MI_SYSTEM_DESC","Administração do módulo Sistema, com as principais configurações do portal.");
define("_MI_SYSTEM_NAME","Sistema");
?>
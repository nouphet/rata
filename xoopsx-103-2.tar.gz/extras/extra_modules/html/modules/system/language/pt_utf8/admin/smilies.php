<?php
define("_AM_DBUPDATED","Banco de dados atualizado corretamente.");
define("_AM_DISPLAYF","Mostrar");
define("_AM_SMILESCONTROL","Configuração dos Emos");
define("_AM_CODE","Código");
define("_AM_SMILIE","Imagem");
define("_AM_ACTION","Ações");
define("_AM_EDIT","Editar");
define("_AM_DEL","Remover");
define("_AM_CNRFTSD","Impossível incluir Emo.");
define("_AM_ADDSMILE","Incluir um emo");
define("_AM_EDITSMILE","Editar um emo");
define("_AM_SMILECODE","Código do emo:");
define("_AM_SMILEURL","URL do emo:");
define("_AM_SMILEEMOTION","Descrição");
define("_AM_ADD","Incluir");
define("_AM_SAVE","Gravar");
define("_AM_WAYSYWTDTS","Deseja remover este emo?");
?>
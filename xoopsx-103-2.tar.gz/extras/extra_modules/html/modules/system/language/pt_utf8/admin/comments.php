<?php
define("_MD_AM_COMMMAN","Administração de comentários");
define("_MD_AM_LISTCOMM","Listar os comentários");
define("_MD_AM_ALLMODS","Todos os módulos");
define("_MD_AM_ALLSTATUS","Qualquer situação");
define("_MD_AM_MODULE","Módulo");
define("_MD_AM_COMFOUND","%s comentário(s) encontrado(s).");
?>
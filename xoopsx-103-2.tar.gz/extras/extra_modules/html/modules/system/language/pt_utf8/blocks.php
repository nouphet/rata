<?php
// *************************************************************** //
// ** XOOPS Cube Legacy - Versão em Português
// ** $Id: blocks.php 336 2009-07-31 09:53:22Z mikhail $
// ** License http://creativecommons.org/licenses/by/2.5/br/
// *************************************************************** //
define("_MB_SYSTEM_ADMENU","Painel de controle");
define("_MB_SYSTEM_ADVS","Pesquisa avançada");
define("_MB_SYSTEM_BFLS","Arquivos corrompidos");
define("_MB_SYSTEM_BLNK","Links inválidos");
define("_MB_SYSTEM_COMPEND","Comentários");
define("_MB_SYSTEM_DISPLAY","Mostrar %s associados");
define("_MB_SYSTEM_DISPLAYA","Mostrar os avatares dos associados");
define("_MB_SYSTEM_DISPLAYC","Mostrar %s comentários");
define("_MB_SYSTEM_EACNT","Editar perfil");
define("_MB_SYSTEM_HOME","Inicial");
define("_MB_SYSTEM_INBOX","Caixa de entrada");
define("_MB_SYSTEM_LOGO","Logotipo no diretório %s");
define("_MB_SYSTEM_LOUT","Sair");
define("_MB_SYSTEM_LPASS","Esqueceu a senha?");
define("_MB_SYSTEM_MFLS","Arquivos modificados");
define("_MB_SYSTEM_MLNKS","Links modificados");
define("_MB_SYSTEM_NODISPGR","Não mostrar os associados cuja graduação é:");
define("_MB_SYSTEM_NOTIF","Notificações");
define("_MB_SYSTEM_NUMTHEME","%s temas");
define("_MB_SYSTEM_PWHEIGHT","Altura da janela pop-up");
define("_MB_SYSTEM_PWWIDTH","Largura da janela pop-up");
define("_MB_SYSTEM_RECO","Recomende-nos");
define("_MB_SYSTEM_RNOW","Registre-se");
define("_MB_SYSTEM_SADMIN","Mostrar os grupos administrativos");
define("_MB_SYSTEM_SEARCH","Pesquisar");
define("_MB_SYSTEM_SECURE","Entrar via conexão segura");
define("_MB_SYSTEM_SEMTO","Enviar uma carta eletrônica para %s");
define("_MB_SYSTEM_SPMTO","Enviar um recado para %s");
define("_MB_SYSTEM_SUBMS","Notícias");
define("_MB_SYSTEM_THSHOW","Mostrar imagem");
define("_MB_SYSTEM_THWIDTH","Largura da imagem");
define("_MB_SYSTEM_VACNT","Perfil");
define("_MB_SYSTEM_WDLS","Arquivos");
define("_MB_SYSTEM_WLNKS","Links");
?>
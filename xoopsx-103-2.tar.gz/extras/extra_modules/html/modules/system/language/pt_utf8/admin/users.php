<?php
// Translation Info
// ********************************************************* //
// ######################################################## //
// ## XOOPS 2.0.9 - Brazilian Portuguese Translation ## //
// ###################################################### //
// ## Translator.....: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.net.br
// ######################################################
// ******************************************************...
define("_AM_ACCESSLEV","Nível de acesso");
define("_AM_ADDUSER","Incluir associado");
define("_AM_AIM","AIM");
define("_AM_AOUTVTEAD","Permitir que os outros associados vejam o meu endereço de e-mail.");
define("_AM_AVATAR","Avatar");
define("_AM_AYSYWTDU","Tem certeza de que deseja remover o associado %s?");
define("_AM_BYTHIS","Serão removidas permanentemente todas as informações deste associado.");
define("_AM_CHANGEONLY","(apenas para alterações)");
define("_AM_CNGTCOM","Não foi possível obter o número total de comentários");
define("_AM_CNGTST","Não foi possível obter o número total de artigos");
define("_AM_CNGUSERID","Não foi possível obter o número identificador do associado");
define("_AM_CNRNU","Não foi possível cadastrar o novo associado.");
define("_AM_CNUUSER","Não foi possível modificar associado");
define("_AM_COMMENTS","Número de textos enviados (sem contar com as notícias):");
define("_AM_DBUPDATED","Informações gravadas corretamente.");
define("_AM_DELUSER","Remover associado");
define("_AM_EDEUSER","Editar ou remover associados");
define("_AM_EMAIL","E-mail");
define("_AM_GO","Prosseguir");
define("_AM_ICQ","ICQ");
define("_AM_INDICATECOF","Os ateriscos (*) indicam os campos obrigatórios.");
define("_AM_INTEREST","Interesses");
define("_AM_LIST","Listar");
define("_AM_LOCATION","Localidade");
define("_AM_MODIFYUSER","Modificar associado");
define("_AM_MSNM","MSNM");
define("_AM_NAME","Nome");
define("_AM_NICKNAME","Codinome");
define("_AM_NO","Não");
define("_AM_NOTACTIVE","Este associado ainda não foi habilitado. Deseja habilitar este associado?");
define("_AM_NOUSERS","Nenhum associado selecionado");
define("_AM_NSRA","Nenhum ranking especial associado");
define("_AM_NSRID","Não há rankings especias no banco de dados");
define("_AM_OCCUPATION","Ocupação");
define("_AM_OPTION","Opção");
define("_AM_PASSWORD","Senha");
define("_AM_PTBBTSDIYT","Clique no botão abaixo para sincronizar os dados, caso você suspeite de que as informações de envio acima não parecem indicar o seu real estado.");
define("_AM_RANK","Posição");
define("_AM_RETYPEPD","Reescreva a senha");
define("_AM_SIGNATURE","Assinatura");
define("_AM_STNPDNM","Lamento, mas as novas senhas não conferem. Retorne e tente de novo.");
define("_AM_STORIES","Notícias");
define("_AM_SYNCHRONIZE","SINCRONIZAR");
define("_AM_THEME","Tema");
define("_AM_UPDATEUSER","Atualizar associado");
define("_AM_URL","URL");
define("_AM_USERDONEXIT","O associado não existe.");
define("_AM_USERID","Nº identificador do associado");
define("_AM_USERINFO","Informações-associado");
define("_AM_USERPOST","Postagens deste associado:");
define("_AM_YES","Sim");
define("_AM_YIM","YIM");
define("_AM_YMCACF","É necessário preencher todos os campos obrigatórios.");
?>
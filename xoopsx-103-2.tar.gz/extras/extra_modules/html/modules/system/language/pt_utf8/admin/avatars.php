<?php
// *************************************************************************
// **	XOOPS	Cube Legacy	-	versão em	português	por	Mikhail	Miguel
// **	$Id: calendar.php	980	2009-04-12 18:45:51Z mikhail.miguel	$
// **	License: http://creativecommons.org/licenses/by/2.5/br/
// **	http://sf.net/users/mikhail	|	http://code.google.com/u/mikhail.miguel
// *************************************************************************
define("_MD_AVATARMAN","Administração dos Avatares");
define("_MD_SYSAVATARS","Avatares do sistema");
define("_MD_CSTAVATARS","Avatares enviados");
define("_MD_ADDAVT","Incluir avatar");
define("_MD_USERS","associados usando este avatar:");
define("_MD_RUDELIMG","Tem certeza de que deseja remover este avatar?");
define("_MD_FAILDEL","Não foi possível remover o avatar %s do banco de dados.");
?>
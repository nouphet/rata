<?php
define("_AM_ACTION","Ações");
define("_AM_ACTIVE","Ativar");
define("_AM_ADD","Incluir");
define("_AM_ADDNEWRANK","Incluir uma nova graduação");
define("_AM_DBUPDATED","Alterações realizadas corretamente.");
define("_AM_DEL","Remover");
define("_AM_EDIT","Editar");
define("_AM_EDITRANK","Editar graduações");
define("_AM_IMAGE","Imagem");
define("_AM_MAXPOST","Máximo de mensagens");
define("_AM_MINPOST","Mínimo de mensagens");
define("_AM_NO","Não");
define("_AM_OFF","Desabilitado");
define("_AM_ON","Habilitado");
define("_AM_RANKSSETTINGS","Configurações das graduações dos associados");
define("_AM_RANKTITLE","Título da graduação");
define("_AM_SAVECHANGE","Gravar alterações");
define("_AM_SPECIAL","Especial");
define("_AM_SPECIALCAN","(graduações especiais podem ser designadas para associados independentemente do número de mensagens enviadas pelos associados)");
define("_AM_SPERANK","Graduações especiais");
define("_AM_TITLE","Título");
define("_AM_VALIDUNDER","(um arquivo de imagem válido no diretório <strong>%s</strong>)");
define("_AM_WAYSYWTDTR","Tem certeza que deseja remover esta graduação?");
define("_AM_YES","Sim");
?>
<?php
// Translation Info
// ********************************************************* //
// ######################################################## //
// ## XOOPS 2.0.9 - Brazilian Portuguese Translation ## //
// ###################################################### //
// ## Translator.....: Mikhail Miguel
// ## E-mail.........: mikhail.miguel@gmail.com
// ## Website........: http://xoops.net.br
// ######################################################
// ******************************************************...
define("_AM_ACCESSRIGHTS","Permissões de acesso aos módulos");
define("_AM_ACTIVERIGHTS","Permissões de administração dos módulos");
define("_AM_ADDBUTTON","incluir »");
define("_AM_ADMINNO","É necessário pelo menos um associado no grupo Adminstradores.");
define("_AM_AREUSUREDEL","Você tem certeza de que deseja remover este grupo?");
define("_AM_BLOCKRIGHTS","Permissões de acesso aos blocos");
define("_AM_CREATENEWADG","Criar um novo grupo");
define("_AM_DBUPDATED","Informações gravadas corretamente.");
define("_AM_DELBUTTON","« remover");
define("_AM_DELETE","Remover");
define("_AM_DELETEADG","Remover grupo");
define("_AM_DESCRIPTION","Descrição");
define("_AM_EDITADG","Editar grupos");
define("_AM_EDITMEMBER","Incluir ou remover associados");
define("_AM_FINDU4GROUP","Incluir ou remover associados");
define("_AM_GROUPSMAIN","Grupos");
define("_AM_IFADMIN","Se a opção de permissão para um módulo estiver assinalada, a permissão de acesso para este módulo estará sempre ligada.");
define("_AM_INDICATES","Os asteriscos indicam os campos obrigatórios");
define("_AM_MEMBERS","Associados");
define("_AM_MODIFY","Modificar");
define("_AM_MODIFYADG","Modificar grupo");
define("_AM_NAME","Nome");
define("_AM_NO","Não");
define("_AM_NONMEMBERS","Não-associados");
define("_AM_SYSTEMRIGHTS","Permissões para a administração do sistema");
define("_AM_UNEED2ENTER","É necessário digitar as informações solicitadas.");
define("_AM_UPDATEADG","Atualizar grupo");
define("_AM_YES","Sim");
?>
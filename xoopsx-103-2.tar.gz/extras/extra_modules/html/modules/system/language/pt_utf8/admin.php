<?php
// *************************************************************************
// **	XOOPS	Cube Legacy	-	versão em	português	por	Mikhail	Miguel
// **	$Id: calendar.php	980	2009-04-12 18:45:51Z mikhail.miguel	$
// **	License: http://creativecommons.org/licenses/by/2.5/br/
// **	http://sf.net/users/mikhail	|	http://code.google.com/u/mikhail.miguel
// *************************************************************************
define("_MD_AM_ADGS","Grupos & permissões");
define("_MD_AM_AVATARS","Avatares");
define("_MD_AM_BANS","Publicidade");
define("_MD_AM_BKAD","Blocos");
define("_MD_AM_COMMENTS","Comentários");
define("_MD_AM_DBUPDATED","As informações foram gravadas corretamente.");
define("_MD_AM_FINDUSER","Localizar associado(s)");
define("_MD_AM_IMAGES","Banco de imagens");
define("_MD_AM_MDAD","Módulos");
define("_MD_AM_MLUS","Enviar e-mail");
define("_MD_AM_PERMADDNG","Could not add %s permission to %s for group %s");
define("_MD_AM_PERMADDNGP","Todos os itens relacionados devem ser selecionados");
define("_MD_AM_PERMADDOK","Incluída a permissão %s em %s para o grupo %s");
define("_MD_AM_PERMRESETNG","Could not reset group permission for module %s");
define("_MD_AM_PREF","Definições");
define("_MD_AM_RANK","Graduações dos associados");
define("_MD_AM_SMLS","Emos");
define("_MD_AM_TPLSETS","Modelos");
define("_MD_AM_USER","Editar associados");
define("_MD_AM_VRSN","Versão");
?>
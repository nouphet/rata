<?php
define("_AM_BADIPCONTAIN","aaa.bbb.ccc irá proibir visitantes com um IP que contenha aaa.bbb.ccc");
define("_AM_BADIPEND","aaa.bbb.ccc$ irá proibir visitantes com um IP que termine com with aaa.bbb.ccc");
define("_AM_BADIPS","Banir endereço IP");
define("_AM_BADIPSTART","aaa.bbb.ccc irá proibir visitantes com um IP que inicie com with aaa.bbb.ccc");
define("_AM_BADUNAMES","Lista de nomes de associados proibidos");
define("_AM_BADWORDS","Lista de palavras censuradas");
define("_AM_DBUPDATED","Informações gravadas corretamente.");
define("_AM_ENTERIPS","Escreva os endereços IP que devem ser banidos deste site. <br/>Escreva apenas um endereço IP por linha.");
define("_AM_ENTERUNAMES","Escreva os nomes que não devem ser usados como nome de associados.<br/>Escreva uma por linha, (maiúsculas são ignoradas).");
define("_AM_ENTERWORDS","Escreva as palavras que devem ser censuradas nas mensagens de associados. As palavras serão substiduídas por ####.<br/>Escreva uma palavra por linha, (maiúsculas são ignoradas).");
define("_AM_FILTERSETTINGS","Configurações de Filtro do Site");
?>
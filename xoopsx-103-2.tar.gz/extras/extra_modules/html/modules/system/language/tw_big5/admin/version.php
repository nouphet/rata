<?php
// $Id: version.php,v 1.1 2008/03/09 02:27:22 minahito Exp $
//%%%%%%	Admin Module Name  Version 	%%%%%
define("_AM_DBUPDATED",_MD_AM_DBUPDATED);


?>

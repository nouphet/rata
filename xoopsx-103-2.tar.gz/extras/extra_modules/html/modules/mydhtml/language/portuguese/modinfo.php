<?php
/**
 * @file
 * @package mydhtml
 * @version $Id: modinfo.php 697 2010-07-07 19:02:25Z mikhail $
*/

define("_MI_MYDHTML_LANG_MYDHTML", "MyDHTML");
define("_MI_MYDHTML_DESC_MYDHTML", "Editor MyDHTML");
?>
<?php
/**
 * @file
 * @package mydhtml
 * @version $Id$
 */

define('_MI_MYDHTML_LANG_MYDHTML', "MYDHTML");
define('_MI_MYDHTML_DESC_MYDHTML', "MYDHTML");

?>

<?php
/**
 * @file
 * @package mydhtml
 * @version $Id$
 */

define('_MI_MYDHTML_LANG_MYDHTML', "MyDHTML");
define('_MI_MYDHTML_DESC_MYDHTML', "Universal Markup Editor and Engine, JQuery plugin");

?>

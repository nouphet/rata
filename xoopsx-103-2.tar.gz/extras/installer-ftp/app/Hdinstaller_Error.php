<?php
/**
 *  Hdinstaller_Error.php
 *
 *  @package   Hdinstaller
 *
 *  $Id: app.error.php 532 2008-05-13 22:41:22Z mumumu-org $
 */

/*--- Application Error Definition ---*/
/*
 *  TODO: Write application error definition here.
 *        Error codes 255 and below are reserved 
 *        by Ethna, so use over 256 value for error code.
 *
 *  Example:
 *  define('E_LOGIN_INVALID', 256);
 */
?>

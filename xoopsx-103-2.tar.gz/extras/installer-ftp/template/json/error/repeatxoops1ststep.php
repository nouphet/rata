<ul class="error">
	<li><?php $this->_('Check XOOPSCube parameters and reClick install button.');?></li>
</ul>

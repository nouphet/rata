<ul class="error">
	<li><?php $this->_('XOOPSCube Install failed. Cleanup created tables.');?></li>
</ul>
<?php include dirname(__FILE__)."/error/repeatxoops1ststep.php";?>

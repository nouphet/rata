<ul class="error">
<?php foreach ($this->getErrors() as $error):?>
<li><?php echo $error; ?></li>
<?php endforeach; ?>
</ul>
